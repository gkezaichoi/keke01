#!/bin/bash
# ─────────────────────────────────────────────────────────────
# build_and_inject.sh
# Compile BonfireCheat.dylib và inject vào IPA
#
# Yêu cầu:
#   - macOS + Xcode Command Line Tools
#   - theos (https://theos.dev) — hoặc compile thủ công với clang
#   - optool hoặc insert_dylib để patch load command
#   - Codesigning: bypass (jailbreak) hoặc re-sign với cert của mày
#
# Usage:
#   chmod +x build_and_inject.sh
#   ./build_and_inject.sh /path/to/TheBonfire2.ipa
# ─────────────────────────────────────────────────────────────

set -e
IPA="${1:-TheBonfire2.ipa}"
DYLIB_NAME="BonfireCheat.dylib"
APP_BUNDLE="Payload/TheBonfire2.app"

# ── Step 1: Compile dylib ────────────────────────────────────
# Cần Substrate SDK. Nếu có theos thì dùng 'make'. Nếu không thì dùng clang trực tiếp.

if command -v make &>/dev/null && [ -f Makefile ]; then
    echo "[*] Building with theos..."
    make clean && make package
    BUILT_DYLIB=$(find .theos -name "*.dylib" | head -1)
else
    echo "[*] Building with clang (manual)..."
    # Cần substrate headers — thường ở /var/jb/usr/include hoặc từ theos
    SUBSTRATE_INC="${THEOS:-/opt/theos}/vendor/include"
    SUBSTRATE_LIB="${THEOS:-/opt/theos}/vendor/lib/libsubstrate.tbd"

    xcrun clang \
        -arch arm64 \
        -isysroot "$(xcrun --sdk iphoneos --show-sdk-path)" \
        -miphoneos-version-min=14.0 \
        -dynamiclib \
        -framework UIKit \
        -framework Foundation \
        -lobjc \
        -I"${SUBSTRATE_INC}" \
        "${SUBSTRATE_LIB}" \
        -fobjc-arc \
        -O2 \
        -o "${DYLIB_NAME}" \
        Tweak.xm

    BUILT_DYLIB="${DYLIB_NAME}"
fi

echo "[+] Built: ${BUILT_DYLIB}"

# ── Step 2: Unpack IPA ──────────────────────────────────────
echo "[*] Unpacking IPA..."
WORK_DIR=$(mktemp -d)
cp "${IPA}" "${WORK_DIR}/app.ipa"
cd "${WORK_DIR}"
unzip -q app.ipa

# ── Step 3: Copy dylib into app bundle ──────────────────────
echo "[*] Injecting dylib..."
cp "${OLDPWD}/${BUILT_DYLIB}" "${APP_BUNDLE}/${DYLIB_NAME}"

# ── Step 4: Add @executable_path load command ────────────────
# Dùng optool hoặc insert_dylib để thêm LC_LOAD_DYLIB
APP_BIN="${APP_BUNDLE}/TheBonfire2"

if command -v optool &>/dev/null; then
    optool install \
        -c load \
        -p "@executable_path/${DYLIB_NAME}" \
        -t "${APP_BIN}"
elif command -v insert_dylib &>/dev/null; then
    insert_dylib \
        --strip-codesig \
        --inplace \
        "@executable_path/${DYLIB_NAME}" \
        "${APP_BIN}"
else
    echo "[!] Cần optool hoặc insert_dylib để patch load command"
    echo "    install: brew install optool"
    echo "    hoặc:    https://github.com/Tyilo/insert_dylib"
    echo ""
    echo "[!] Nếu IPA đã dùng blatantsPatch.dylib (như file này),"
    echo "    chỉ cần đặt BonfireCheat.dylib cạnh blatantsPatch.dylib"
    echo "    — substrate sẽ tự load cả 2. KHÔNG cần patch binary."
fi

# ── Step 5: Re-sign (nếu cần) ───────────────────────────────
# Trên jailbreak thường không cần. Trên TrollStore / sideload thì cần.
echo "[*] Skipping codesign (jailbreak assumed — fakesign nếu cần)"
# Uncomment và điền cert nếu mày cần sideload:
# CERT="iPhone Developer: Your Name (XXXXXXXXXX)"
# codesign --force --sign "${CERT}" --entitlements entitlements.plist "${APP_BIN}"
# codesign --force --sign "${CERT}" "${APP_BUNDLE}/${DYLIB_NAME}"

# ── Step 6: Repack IPA ──────────────────────────────────────
echo "[*] Repacking IPA..."
cd "${WORK_DIR}"
zip -qr "${OLDPWD}/TheBonfire2_Cheated.ipa" Payload/

echo ""
echo "[+] Done: TheBonfire2_Cheated.ipa"
echo ""
echo "    Nếu IPA này đã có blatantsPatch.dylib + libsubstrate,"
echo "    chỉ cần copy BonfireCheat.dylib vào bundle là đủ."
echo "    Substrate tự scan và load tất cả dylib trong app bundle."
echo ""
echo "    Mở Settings trong game → kéo xuống dưới → CHEAT MENU hiện ra."

# Cleanup
rm -rf "${WORK_DIR}"

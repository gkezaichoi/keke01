# BonfireCheat.dylib — The Bonfire 2: Uncharted Shores

Cheat menu inject vào Settings, toggle on/off từng tính năng.

---

## Tính năng

| Toggle | Mô tả |
|--------|-------|
| ♾ Infinite Resources | `GetResourceQuantity` luôn trả về 999, `RemoveResource` bị block → không bao giờ hết tài nguyên |
| ☠ God Mode | `TakeDamage` → no-op, nhân vật không nhận damage |
| ⚔ One-Hit Kill | `WeaponAttack` → gọi `TakeDamage(99999)` lên target, mọi enemy chết 1 đòn |
| 🏗 Instant Build | `UpdateConstruction` → gọi thẳng `FinishConstruction`, công trình xây xong ngay |
| 🌊 No Enemy Waves | `CastleEnemies.SpawnWave` → no-op, không có wave nào spawn |
| ☀ Freeze Day/Night | `DayNightController.Update` → no-op, thời gian đứng yên |
| 🔓 Unlock All Buildings | `HasEnoughResourcesToStartConstruction` → luôn `true` |

---

## Cách dùng trong game

1. Mở **Settings** (biểu tượng bánh răng)
2. Kéo xuống dưới cùng → thấy panel **⚡ CHEAT MENU** nền tối
3. Toggle on/off từng tính năng
4. Panel có thể kéo (drag) để di chuyển nếu che UI

---

## Build & Inject

### Yêu cầu
- macOS + Xcode CLT
- [theos](https://theos.dev) (khuyến nghị) hoặc clang + substrate headers
- `optool` hoặc `insert_dylib` để thêm load command
- IPA đã jailbreak-patched (file mày gửi đã có `blatantsPatch.dylib` + `libsubstrate.dylib`)

### Compile với theos
```bash
cd cheat_bonfire2
make clean && make package
```

### Compile thủ công (clang)
```bash
xcrun clang \
  -arch arm64 \
  -isysroot $(xcrun --sdk iphoneos --show-sdk-path) \
  -miphoneos-version-min=14.0 \
  -dynamiclib \
  -framework UIKit -framework Foundation -lobjc \
  -I/opt/theos/vendor/include \
  /opt/theos/vendor/lib/libsubstrate.tbd \
  -fobjc-arc -O2 \
  -o BonfireCheat.dylib \
  Tweak.xm
```

### Inject vào IPA
```bash
chmod +x build_and_inject.sh
./build_and_inject.sh /path/to/TheBonfire2.ipa
```

### Cách nhanh (IPA này đã có substrate)
IPA mày gửi đã có `blatantsPatch.dylib` — substrate scan tất cả dylib trong bundle. Chỉ cần:
1. Unzip IPA
2. Copy `BonfireCheat.dylib` vào `Payload/TheBonfire2.app/`
3. Rezip → install

**Không cần** patch binary hay thêm load command.

---

## Kỹ thuật

- **IL2CPP runtime resolution**: dùng `il2cpp_class_from_name` + `il2cpp_class_get_method_from_name` để tìm method pointer — không hardcode offset → không bị break nếu game update nhỏ
- **Substrate MSHookFunction**: hook native arm64 function tại địa chỉ runtime
- **ObjC swizzle**: viewDidAppear trên UIViewController để detect khi Settings mở
- **UI**: thuần UIKit, không dùng bất kỳ framework nào thêm

---

## Hook map

```
AgentInventory::TakeDamage(int, AgentInventory*)     → hook_TakeDamage
AgentInventory::GetResourceQuantity(ResourceData*)   → hook_GetResourceQuantity  
AgentInventory::RemoveResource(ResourceData*, int)   → hook_RemoveResource
AgentInventory::WeaponAttack(AgentInventory*)        → hook_WeaponAttack
Building::UpdateConstruction(int)                    → hook_UpdateConstruction
Building::HasEnoughResourcesToStartConstruction()    → hook_HasEnoughResources
CastleEnemies::SpawnWave()                           → hook_SpawnWave
DayNightController::Update()                         → hook_DNC_Update
UIViewController::viewDidAppear:                     → hook_viewDidAppear (cheat panel)
```

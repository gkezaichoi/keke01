/*
 * BonfireCheat.xm
 * The Bonfire 2: Uncharted Shores — iOS Cheat Menu
 * Substrate hook, injected at Settings panel (settingsMenu)
 *
 * Architecture  : arm64 (IL2CPP Unity)
 * Substrate lib : libsubstrate / MobileSubstrate
 * Hook targets  :
 *   - settingsMenu         → injects cheat UI panel
 *   - AgentInventory.TakeDamage  → god mode (skip damage)
 *   - AgentInventory.AddResource / SetResource / GetResourceQuantity → resource hooks
 *   - Building.UpdateConstruction / FinishConstruction → instant build
 *   - CastleEnemies        → no enemy waves
 *   - DayNightController   → freeze day/night
 *
 * Entry point: dylib constructor (_ctor) registers add_image callback,
 * resolves IL2CPP class/method pointers at runtime via il2cpp_class_from_name
 * and il2cpp_method_get_from_name, then MSHookFunction on each.
 *
 * HOW TO USE:
 *   Compile → drop BonfireCheat.dylib into IPA's Payload/TheBonfire2.app/
 *   Add entry to Info.plist Frameworks if needed, or inject via blatantsPatch
 *   (the existing substrate patcher will load it automatically if placed in
 *    the app bundle alongside blatantsPatch.dylib)
 *
 *   In-game: open Settings → scroll to bottom → "CHEAT MENU" section appears
 */

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <substrate.h>
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <stdint.h>
#include <string.h>
#include <pthread.h>

// ─────────────────────────────────────────────────────────────
// MARK: IL2CPP runtime typedefs (subset we need)
// ─────────────────────────────────────────────────────────────

typedef struct Il2CppObject Il2CppObject;
typedef struct Il2CppClass  Il2CppClass;
typedef struct Il2CppDomain Il2CppDomain;
typedef struct Il2CppImage  Il2CppImage;
typedef struct MethodInfo   MethodInfo;

typedef Il2CppDomain*  (*il2cpp_domain_get_t)(void);
typedef Il2CppImage**  (*il2cpp_domain_get_assemblies_t)(Il2CppDomain*, size_t*);
typedef Il2CppImage*   (*il2cpp_assembly_get_image_t)(void*);
typedef Il2CppClass*   (*il2cpp_class_from_name_t)(Il2CppImage*, const char*, const char*);
typedef MethodInfo*    (*il2cpp_class_get_method_from_name_t)(Il2CppClass*, const char*, int);
typedef void*          (*il2cpp_method_get_pointer_t)(MethodInfo*);
typedef Il2CppObject*  (*il2cpp_object_new_t)(Il2CppClass*);
typedef void*          (*il2cpp_class_get_field_from_name_t)(Il2CppClass*, const char*);
typedef void           (*il2cpp_field_get_value_t)(Il2CppObject*, void*, void*);
typedef void           (*il2cpp_field_set_value_t)(Il2CppObject*, void*, void*);

// ─────────────────────────────────────────────────────────────
// MARK: Cheat state (all off by default)
// ─────────────────────────────────────────────────────────────

typedef struct {
    BOOL godMode;          // TakeDamage → no-op
    BOOL oneHitKill;       // outgoing damage ×999
    BOOL infiniteResources;// GetResourceQuantity always returns 999; AddResource no deduct
    BOOL instantBuild;     // UpdateConstruction → immediately call FinishConstruction
    BOOL noWaves;          // CastleEnemies.SpawnWave → no-op
    BOOL freezeDay;        // DayNightController.Update → no time advance
    BOOL unlockAllBuildings; // HasEnoughResourcesToStartConstruction → true
} CheatState;

static CheatState g_cheat = {0};

// ─────────────────────────────────────────────────────────────
// MARK: IL2CPP symbol resolution helpers
// ─────────────────────────────────────────────────────────────

// Base address of UnityFramework (where IL2CPP lives)
static uintptr_t g_framework_base = 0;

// IL2CPP API function pointers (resolved lazily from UnityFramework)
static il2cpp_class_from_name_t            il2cpp_class_from_name            = NULL;
static il2cpp_class_get_method_from_name_t il2cpp_class_get_method_from_name = NULL;
static il2cpp_field_get_value_t            il2cpp_field_get_value            = NULL;
static il2cpp_field_set_value_t            il2cpp_field_set_value            = NULL;
static il2cpp_class_get_field_from_name_t  il2cpp_class_get_field_from_name  = NULL;

// Main app image (Assembly-CSharp.dll equivalent — in IL2CPP this is just "Assembly-CSharp")
static Il2CppImage* g_game_image = NULL;

// ─────────────────────────────────────────────────────────────
// MARK: Method pointers we hook (originals stored here)
// ─────────────────────────────────────────────────────────────

// AgentInventory – void TakeDamage(int damageValue, Il2CppObject* attacker)
static void (*orig_TakeDamage)(Il2CppObject*, int, Il2CppObject*, void*) = NULL;
static void hook_TakeDamage(Il2CppObject* self, int damageValue, Il2CppObject* attacker, void* method)
{
    /*
     * self     = AgentInventory instance
     * On god mode: skip damage entirely. On one-hit-kill we amplify *outgoing*
     * damage; that requires hooking the caller side (WeaponAttack), handled separately.
     * Here we just block incoming.
     */
    if (g_cheat.godMode) return; // *I am a wall they can't climb.*
    orig_TakeDamage(self, damageValue, attacker, method);
}

// AgentInventory – int GetResourceQuantity(Il2CppObject* type)
static int (*orig_GetResourceQuantity)(Il2CppObject*, Il2CppObject*, void*) = NULL;
static int hook_GetResourceQuantity(Il2CppObject* self, Il2CppObject* type, void* method)
{
    /*
     * Called before any resource check (crafting, building, trading).
     * Return 999 so every check passes.
     */
    if (g_cheat.infiniteResources) return 999; // *I lie about what we have. Works every time.*
    return orig_GetResourceQuantity(self, type, method);
}

// AgentInventory – void RemoveResource(Il2CppObject* type, int quantity)
static void (*orig_RemoveResource)(Il2CppObject*, Il2CppObject*, int, void*) = NULL;
static void hook_RemoveResource(Il2CppObject* self, Il2CppObject* type, int quantity, void* method)
{
    /*
     * Block resource deduction when infinite mode is on.
     * Resources visually stay at whatever the display shows; cost is eaten.
     */
    if (g_cheat.infiniteResources) return; // *The ledger never closes.*
    orig_RemoveResource(self, type, quantity, method);
}

// Building – void UpdateConstruction(int addedLabour)
// Signature confirmed from metadata: addedLabour → int
static void (*orig_UpdateConstruction)(Il2CppObject*, int, void*) = NULL;
static void hook_UpdateConstruction(Il2CppObject* self, int addedLabour, void* method)
{
    /*
     * Called each worker-tick. On instant build we skip the accumulation
     * and jump straight to FinishConstruction on the same object.
     * We need the FinishConstruction pointer resolved; if not yet resolved,
     * fall through normally this tick.
     */
    if (g_cheat.instantBuild) {
        // FinishConstruction is resolved separately in g_ptr_FinishConstruction
        extern void (*g_ptr_FinishConstruction)(Il2CppObject*, void*);
        if (g_ptr_FinishConstruction) {
            g_ptr_FinishConstruction(self, NULL);
            return; // *Done. The workers believe they worked for weeks.*
        }
    }
    orig_UpdateConstruction(self, addedLabour, method);
}

// Building – void FinishConstruction() (no args beyond self/method)
void (*g_ptr_FinishConstruction)(Il2CppObject*, void*) = NULL;

// CastleEnemies – void SpawnWave() / NekronHurt variant
// Metadata shows: CastleEnemies.monsterCount, CastleEnemies.caveEnemies etc.
// SpawnWave is the most common entry; we no-op it when noWaves is on.
static void (*orig_SpawnWave)(Il2CppObject*, void*) = NULL;
static void hook_SpawnWave(Il2CppObject* self, void* method)
{
    if (g_cheat.noWaves) return; // *The horde never assembled. Nobody told them.*
    orig_SpawnWave(self, method);
}

// DayNightController – void Update() (Unity lifecycle)
static void (*orig_DNC_Update)(Il2CppObject*, void*) = NULL;
static void hook_DNC_Update(Il2CppObject* self, void* method)
{
    if (g_cheat.freezeDay) return; // *The sun hangs. Nobody minds.*
    orig_DNC_Update(self, method);
}

// Building – bool HasEnoughResourcesToStartConstruction()
static bool (*orig_HasEnoughResources)(Il2CppObject*, void*) = NULL;
static bool hook_HasEnoughResources(Il2CppObject* self, void* method)
{
    if (g_cheat.unlockAllBuildings) return true; // *Pre-approved.*
    return orig_HasEnoughResources(self, method);
}

// ─────────────────────────────────────────────────────────────
// MARK: IL2CPP image / class / method resolution
// ─────────────────────────────────────────────────────────────

/*
 * The Bonfire 2 is fully IL2CPP. All C# game logic compiles into native arm64
 * code inside UnityFramework. The global-metadata.dat maps type/method names
 * to offsets; at runtime il2cpp exposes class_from_name and
 * class_get_method_from_name so we can resolve function pointers without
 * hardcoding offsets (update-resistant).
 *
 * We load UnityFramework's dylib image, dlsym the il2cpp API, then walk
 * the domain to find the game assembly image (named "" in IL2CPP since
 * everything is AOT'd into the framework binary — we just need image index 0).
 */

static void resolve_il2cpp_api(void)
{
    // UnityFramework is a separate dylib in modern Unity iOS
    void* fw = dlopen("@rpath/UnityFramework.framework/UnityFramework", RTLD_NOW | RTLD_NOLOAD);
    if (!fw) {
        // fallback: scan loaded images
        for (uint32_t i = 0; i < _dyld_image_count(); i++) {
            const char* name = _dyld_get_image_name(i);
            if (name && strstr(name, "UnityFramework")) {
                g_framework_base = (uintptr_t)_dyld_get_image_vmaddr_slide(i);
                // try dlopen with resolved path
                fw = dlopen(name, RTLD_NOW | RTLD_NOLOAD);
                break;
            }
        }
    }
    if (!fw) return;

    il2cpp_class_from_name            = (il2cpp_class_from_name_t)            dlsym(fw, "il2cpp_class_from_name");
    il2cpp_class_get_method_from_name  = (il2cpp_class_get_method_from_name_t) dlsym(fw, "il2cpp_class_get_method_from_name");
    il2cpp_field_get_value             = (il2cpp_field_get_value_t)            dlsym(fw, "il2cpp_field_get_value");
    il2cpp_field_set_value             = (il2cpp_field_set_value_t)            dlsym(fw, "il2cpp_field_set_value");
    il2cpp_class_get_field_from_name   = (il2cpp_class_get_field_from_name_t)  dlsym(fw, "il2cpp_class_get_field_from_name");

    // Get the game assembly image
    // In IL2CPP the primary game image is accessible as domain image index 0
    // We use il2cpp_domain_get_assemblies then pick the one whose name is ""
    typedef Il2CppDomain* (*dom_get_t)(void);
    typedef void**         (*dom_assem_t)(Il2CppDomain*, size_t*);
    typedef Il2CppImage*   (*assem_img_t)(void*);

    dom_get_t    dom_get    = (dom_get_t)    dlsym(fw, "il2cpp_domain_get");
    dom_assem_t  dom_assem  = (dom_assem_t)  dlsym(fw, "il2cpp_domain_get_assemblies");
    assem_img_t  assem_img  = (assem_img_t)  dlsym(fw, "il2cpp_assembly_get_image");

    if (!dom_get || !dom_assem || !assem_img) return;

    Il2CppDomain* domain = dom_get();
    size_t count = 0;
    void** assemblies = dom_assem(domain, &count);
    if (!assemblies) return;

    // Walk assemblies to find the game one (name contains "Assembly-CSharp" or is "")
    typedef const char* (*img_name_t)(Il2CppImage*);
    img_name_t img_name = (img_name_t)dlsym(fw, "il2cpp_image_get_name");

    for (size_t i = 0; i < count; i++) {
        Il2CppImage* img = assem_img(assemblies[i]);
        if (!img) continue;
        const char* name = img_name ? img_name(img) : NULL;
        // IL2CPP game assembly is typically "" or "Assembly-CSharp.dll"
        if (!name || strcmp(name, "") == 0 || strstr(name, "Assembly-CSharp")) {
            g_game_image = img;
            break;
        }
    }
    // If we didn't find it by name, image[0] is usually the game one
    if (!g_game_image && count > 0) {
        g_game_image = assem_img(assemblies[0]);
    }
}

// Helper: resolve a method pointer and hook it
// namespace_ can be NULL or ""
static void hook_method(const char* namespace_, const char* class_name,
                        const char* method_name, int param_count,
                        void* hook_fn, void** orig_out)
{
    if (!g_game_image || !il2cpp_class_from_name || !il2cpp_class_get_method_from_name) return;

    Il2CppClass* klass = il2cpp_class_from_name(g_game_image, namespace_ ? namespace_ : "", class_name);
    if (!klass) return;

    MethodInfo* method = il2cpp_class_get_method_from_name(klass, method_name, param_count);
    if (!method) return;

    // method->methodPointer is the native function address (IL2CPP AOT)
    // Layout: first field of MethodInfo is Il2CppMethodPointer methodPointer
    void** method_ptr_field = (void**)method; // offset 0 = methodPointer in most IL2CPP versions
    void* native_fn = *method_ptr_field;
    if (!native_fn) return;

    MSHookFunction(native_fn, hook_fn, orig_out);
}

// ─────────────────────────────────────────────────────────────
// MARK: Cheat Panel UI — injected into settingsMenu
// ─────────────────────────────────────────────────────────────
//
// We swizzle settingsMenu's viewDidAppear: (ObjC wrapper Unity creates)
// and append a custom UIView with UISwitch toggles at the bottom.
//
// The game's settingsMenu is an ObjC class wrapping the C# component —
// Unity generates ObjC wrappers for MonoBehaviour subclasses on iOS.
//

static UIView*  g_cheat_panel   = nil;
static NSArray* g_cheat_switches = nil;

static NSString* const kCheatTitles[] = {
    @"♾ Infinite Resources",
    @"☠ God Mode (No Damage)",
    @"⚔ One-Hit Kill",
    @"🏗 Instant Build",
    @"🌊 No Enemy Waves",
    @"☀ Freeze Day/Night",
    @"🔓 Unlock All Buildings",
};
static const NSUInteger kCheatCount = 7;

// Map switch index → the cheat bool inside g_cheat
static BOOL* cheat_ptr(NSUInteger idx)
{
    switch (idx) {
        case 0: return &g_cheat.infiniteResources;
        case 1: return &g_cheat.godMode;
        case 2: return &g_cheat.oneHitKill;
        case 3: return &g_cheat.instantBuild;
        case 4: return &g_cheat.noWaves;
        case 5: return &g_cheat.freezeDay;
        case 6: return &g_cheat.unlockAllBuildings;
        default: return NULL;
    }
}

@interface BFCheatController : NSObject
+ (void)switchToggled:(UISwitch*)sw;
@end

@implementation BFCheatController
+ (void)switchToggled:(UISwitch*)sw
{
    /*
     * sw.tag == cheat index
     * *I update the flag and let the hooks do the rest silently.*
     */
    BOOL* ptr = cheat_ptr((NSUInteger)sw.tag);
    if (ptr) *ptr = sw.isOn;

    // Visual pulse so the player knows it registered
    UIView* parent = sw.superview;
    [UIView animateWithDuration:0.08 animations:^{
        parent.alpha = 0.6f;
    } completion:^(BOOL done) {
        [UIView animateWithDuration:0.12 animations:^{ parent.alpha = 1.0f; }];
    }];
}
@end

// Builds the cheat panel UIView that gets added to the settings screen
static UIView* build_cheat_panel(CGRect bounds)
{
    // ── Panel container ──────────────────────────────────────────
    CGFloat panelW  = bounds.size.width * 0.90f;
    CGFloat rowH    = 48.0f;
    CGFloat headerH = 44.0f;
    CGFloat padding = 12.0f;
    CGFloat panelH  = headerH + (rowH * kCheatCount) + padding * 2;
    CGFloat panelX  = (bounds.size.width - panelW) / 2.0f;
    CGFloat panelY  = bounds.size.height - panelH - 20.0f; // near bottom

    UIView* panel = [[UIView alloc] initWithFrame:CGRectMake(panelX, panelY, panelW, panelH)];
    panel.backgroundColor = [UIColor colorWithRed:0.05f green:0.05f blue:0.10f alpha:0.93f];
    panel.layer.cornerRadius = 14.0f;
    panel.layer.borderColor  = [UIColor colorWithRed:0.9f green:0.7f blue:0.1f alpha:0.8f].CGColor;
    panel.layer.borderWidth  = 1.5f;
    panel.clipsToBounds      = YES;

    // Draggable (UIPanGestureRecognizer)
    UIPanGestureRecognizer* pan = [[UIPanGestureRecognizer alloc]
        initWithTarget:[BFCheatController class]
                action:@selector(handlePan:)];
    [panel addGestureRecognizer:pan];

    // ── Header label ─────────────────────────────────────────────
    UILabel* header = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, panelW, headerH)];
    header.text          = @"⚡ CHEAT MENU";
    header.textAlignment = NSTextAlignmentCenter;
    header.font          = [UIFont boldSystemFontOfSize:16.0f];
    header.textColor     = [UIColor colorWithRed:1.0f green:0.85f blue:0.2f alpha:1.0f];
    header.backgroundColor = [UIColor colorWithRed:0.10f green:0.08f blue:0.20f alpha:1.0f];
    [panel addSubview:header];

    // ── Toggle rows ───────────────────────────────────────────────
    NSMutableArray* switches = [NSMutableArray array];

    for (NSUInteger i = 0; i < kCheatCount; i++) {
        CGFloat rowY = headerH + padding + rowH * i;

        UIView* row = [[UIView alloc] initWithFrame:CGRectMake(0, rowY, panelW, rowH)];
        row.backgroundColor = (i % 2 == 0)
            ? [UIColor colorWithRed:0.08f green:0.08f blue:0.15f alpha:1.0f]
            : [UIColor colorWithRed:0.06f green:0.06f blue:0.12f alpha:1.0f];
        [panel addSubview:row];

        UILabel* lbl = [[UILabel alloc] initWithFrame:CGRectMake(12, 0, panelW - 80, rowH)];
        lbl.text      = kCheatTitles[i];
        lbl.font      = [UIFont systemFontOfSize:13.0f weight:UIFontWeightMedium];
        lbl.textColor = [UIColor colorWithRed:0.9f green:0.9f blue:0.95f alpha:1.0f];
        [row addSubview:lbl];

        UISwitch* sw = [[UISwitch alloc] init];
        sw.tag = (NSInteger)i;
        sw.on  = *cheat_ptr(i);
        [sw setOnTintColor:[UIColor colorWithRed:0.2f green:0.8f blue:0.3f alpha:1.0f]];
        CGFloat swX = panelW - sw.frame.size.width - 12.0f;
        CGFloat swY = (rowH - sw.frame.size.height) / 2.0f;
        sw.frame = CGRectMake(swX, swY, sw.frame.size.width, sw.frame.size.height);
        [sw addTarget:[BFCheatController class]
               action:@selector(switchToggled:)
     forControlEvents:UIControlEventValueChanged];
        [row addSubview:sw];
        [switches addObject:sw];
    }

    g_cheat_switches = [switches copy];
    return panel;
}

// Pan gesture handler to let player drag the panel around
@implementation BFCheatController (Pan)
+ (void)handlePan:(UIPanGestureRecognizer*)gr
{
    UIView* v = gr.view;
    CGPoint delta = [gr translationInView:v.superview];
    v.center = CGPointMake(v.center.x + delta.x, v.center.y + delta.y);
    [gr setTranslation:CGPointZero inView:v.superview];
}
@end

// ─────────────────────────────────────────────────────────────
// MARK: settingsMenu viewDidAppear swizzle
// ─────────────────────────────────────────────────────────────
//
// Unity MonoBehaviour-derived ObjC wrappers don't have viewDidAppear,
// but they ARE subclasses of UIViewController. We hook UIViewController's
// viewDidAppear: and filter on the class name.
//

static void (*orig_viewDidAppear)(id self, SEL sel, BOOL animated) = NULL;
static void hook_viewDidAppear(id self, SEL sel, BOOL animated)
{
    orig_viewDidAppear(self, sel, animated);

    NSString* className = NSStringFromClass([self class]);
    if (![className containsString:@"settingsMenu"] && ![className containsString:@"SettingsMenu"]) return;

    UIViewController* vc = (UIViewController*)self;
    UIView* root = vc.view;

    // Remove any previously injected panel first
    for (UIView* sub in root.subviews) {
        if (sub.tag == 0xBF42) {
            [sub removeFromSuperview];
        }
    }

    // Build and insert new panel
    // *Slipping in uninvited. Nobody checks the guest list.*
    dispatch_async(dispatch_get_main_queue(), ^{
        UIView* panel = build_cheat_panel(root.bounds);
        panel.tag = 0xBF42; // sentinel so we can find/replace it
        [root addSubview:panel];
        g_cheat_panel = panel;
    });
}

// ─────────────────────────────────────────────────────────────
// MARK: One-Hit Kill — hook damage output
// ─────────────────────────────────────────────────────────────
//
// From metadata: WeaponAttack is the method on AgentInventory that
// calls TakeDamage on the target. We intercept there and multiply.
// Signature: void WeaponAttack(Il2CppObject* target)
//

static void (*orig_WeaponAttack)(Il2CppObject*, Il2CppObject*, void*) = NULL;
static void hook_WeaponAttack(Il2CppObject* self, Il2CppObject* target, void* method)
{
    /*
     * self   = attacker AgentInventory
     * target = victim  AgentInventory
     * On one-hit-kill: call TakeDamage directly on target with a lethal value.
     * We don't know exact HP cap so 99999 is enough.
     */
    if (g_cheat.oneHitKill && orig_TakeDamage && target) {
        orig_TakeDamage(target, 99999, self, NULL);
        return; // *One motion. End of the argument.*
    }
    orig_WeaponAttack(self, target, method);
}

// ─────────────────────────────────────────────────────────────
// MARK: Initialisation — called from dylib constructor
// ─────────────────────────────────────────────────────────────

static void* init_thread(void* unused)
{
    // Give Unity time to initialise IL2CPP before we resolve
    [NSThread sleepForTimeInterval:3.0];

    resolve_il2cpp_api();
    if (!g_game_image) return NULL; // *Can't hook what we can't find.*

    // ── IL2CPP method hooks ───────────────────────────────────
    // namespace = "" for game scripts in The Bonfire 2 (no custom namespace found)

    hook_method("", "AgentInventory", "TakeDamage",      2, (void*)hook_TakeDamage,          (void**)&orig_TakeDamage);
    hook_method("", "AgentInventory", "GetResourceQuantity", 1, (void*)hook_GetResourceQuantity, (void**)&orig_GetResourceQuantity);
    hook_method("", "AgentInventory", "RemoveResource",   2, (void*)hook_RemoveResource,      (void**)&orig_RemoveResource);
    hook_method("", "AgentInventory", "WeaponAttack",     1, (void*)hook_WeaponAttack,        (void**)&orig_WeaponAttack);
    hook_method("", "Building",       "UpdateConstruction", 1, (void*)hook_UpdateConstruction, (void**)&orig_UpdateConstruction);
    hook_method("", "CastleEnemies",  "SpawnWave",        0, (void*)hook_SpawnWave,           (void**)&orig_SpawnWave);
    hook_method("", "DayNightController", "Update",       0, (void*)hook_DNC_Update,          (void**)&orig_DNC_Update);
    hook_method("", "Building",       "HasEnoughResourcesToStartConstruction", 0,
                (void*)hook_HasEnoughResources, (void**)&orig_HasEnoughResources);

    // Resolve FinishConstruction pointer (used by instant-build hook, not hooked itself)
    if (g_game_image && il2cpp_class_from_name && il2cpp_class_get_method_from_name) {
        Il2CppClass* kBuild = il2cpp_class_from_name(g_game_image, "", "Building");
        if (kBuild) {
            MethodInfo* m = il2cpp_class_get_method_from_name(kBuild, "FinishConstruction", 0);
            if (m) g_ptr_FinishConstruction = *(void**)m;
        }
    }

    // ── ObjC settingsMenu hook (UI injection) ─────────────────
    // Hook at UIViewController level; filter on class name in the hook body
    Class vcClass = objc_getClass("UIViewController");
    if (vcClass) {
        SEL sel = @selector(viewDidAppear:);
        Method m = class_getInstanceMethod(vcClass, sel);
        if (m) {
            orig_viewDidAppear = (void(*)(id,SEL,BOOL))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_viewDidAppear);
        }
    }

    return NULL;
}

// ─────────────────────────────────────────────────────────────
// MARK: Dylib entry
// ─────────────────────────────────────────────────────────────

__attribute__((constructor))
static void dylib_init(void)
{
    /*
     * Called when the dylib loads. Substrate is already active at this point
     * (blatantsPatch.dylib loads us). We spin a thread so we don't block the
     * main loader — IL2CPP isn't ready yet at constructor time.
     * *The quiet guest who arrived early and rearranged the furniture.*
     */
    pthread_t t;
    pthread_create(&t, NULL, init_thread, NULL);
    pthread_detach(t);
}
